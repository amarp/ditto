#!/bin/bash -x

ssh -n $1 "~/OLSR/scripts/setup-olsr.sh" 
#ssh -n $1 "./setup-olsr.sh" 
