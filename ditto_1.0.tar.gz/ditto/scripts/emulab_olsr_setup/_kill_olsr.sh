#!/bin/bash -x

ssh -n $1 "sudo kill -9 olsrd" 
