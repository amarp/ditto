#!/bin/bash -x

ssh $1 "sudo yum install iperf";
