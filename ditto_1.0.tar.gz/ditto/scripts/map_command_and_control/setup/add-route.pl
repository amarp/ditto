#!/usr/bin/perl -W

use strict 'vars';

my $TESTBED;
my $NODE_LIST;

my $NUM_NODES = 38;
my $WIRELESS_INTERFACE = "ath0";
#my $WIRELESS_INTERFACE = "wlan0";
my $POWER = -1; #change it to something +ve based on testbed and interface
my $DOT_PATH = "/tmp/";
my $GATEWAY = "map11";

#for tcsh                                                                                                                              
my $REDIRECT = ">&";
#for bash 
#my $REDIRECT = "2>&1 | tee";   

my $IP;

my %allinterfaces = ();
my %allips = ();
my @allhosts = ();
my %done = ();

sub get_interface {
    my $name = @_;

    if ($TESTBED eq "map") {
        return $WIRELESS_INTERFACE;
    }
    
    if ($TESTBED eq "emulab") {
        my $cmd = "ssh $name 'ifconfig | grep ath0 | wc -l'";
        open(IP, "$cmd | ");
        my $linecount = <IP>; chomp $linecount;
        close(IP);
        if ($linecount == 1) {
            return "ath0";
        }
        else  {
            return "ath1";
        }
    }
}

sub get_ip {
    my ($name) = @_;

    my $ip;
    my $cmd = "ssh $name \"/sbin/ifconfig | grep '$IP' | awk '{print \$2}'\"";
    print "$cmd\n";
    open(IP, "$cmd | ");
    my $linecount = <IP>; chomp $linecount;
    if ($linecount =~ /.*?addr\:(\d+\.\d+\.\d+\.\d+)/ ) {
        $ip = $1;
    }
    close(IP);
    print "$name $linecount $ip\n";
    return($ip);
}

sub cleanup_routing {

    print "Cleanup routing\n";

    my $cmd = "./do-perhost.pl -t 120 -c 200 -f $NODE_LIST \"ssh \@HOST\@ 'sudo killall -9 olsrd-emulab olsrd-map'\"";
    print "$cmd\n";
    system($cmd);
    
    if ($TESTBED eq "map") {
	for (my $i = 1; $i <= $NUM_NODES; $i++) {
	    $cmd = "./do-perhost.pl -t 120 -c 200 -f $NODE_LIST \"ssh \@HOST\@ 'sudo route del -host 1.0.0.$i' \" >& /dev/null";
	    print "$cmd\n";
	    system($cmd);
	    
	    $cmd = "./do-perhost.pl -t 120 -c 200 -f $NODE_LIST \"ssh \@HOST\@ 'sudo route del -host 2.0.0.$i' \" >& /dev/null";
	    print "$cmd\n";
	    system($cmd);
	}
    }
    elsif ($TESTBED eq "emulab") {
	$cmd = "./do-perhost.pl -t 120 -c 200 -f $NODE_LIST \"ssh \@HOST\@ 'sudo route del -net 10.1.0.0 netmask 255.255.255.0'\"";
	print "$cmd\n";
	system($cmd);
    }
    
    print "-----------------------------------------------\n";
}

sub setup_hard_route {
    #@allhosts --> path from recvr to gateway
    for (my $i = 0; $i < $#allhosts; $i++) {
	my $cmd;
	my $route;
	if ($i != $#allhosts - 1) {
	    $cmd = "ssh $allhosts[$i] 'sudo route add -host $allips{$allhosts[$#allhosts]} gw $allips{$allhosts[$i+1]} dev $allinterfaces{$allhosts[$i]}'";
	    $route = "$allhosts[$i]-$allhosts[$#allhosts]";
	}
	else {
	    $cmd = "ssh $allhosts[$i] 'sudo route add -host $allips{$allhosts[$#allhosts]} dev $allinterfaces{$allhosts[$i]}'";
	    $route = "$allhosts[$i]-$allhosts[$#allhosts]";
	}
	if (! defined $done{$route}) {
	    print "$cmd\n";
	    system($cmd);
	    $done{$route} = 1;
	}
    }

    #setup from gw to recvr
    for (my $i = $#allhosts; $i > 0; $i--) {
	my $cmd;
	my $route;

	$cmd = "ssh $allhosts[$i] 'sudo route add -host $allips{$allhosts[$i-1]} dev $allinterfaces{$allhosts[$i]}'";
	$route = "$allhosts[$i]-$allhosts[$i-1]";
	if (! defined $done{$route}) {
	    print "$cmd\n";
	    system($cmd);
	    $done{$route} = 1;
	}
	
	for (my $j = $i-2; $j >= 0; $j--) {
	    $cmd = "ssh $allhosts[$i] 'sudo route add -host $allips{$allhosts[$j]} gw $allips{$allhosts[$i-1]} dev $allinterfaces{$allhosts[$i]}'";
	    $route = "$allhosts[$i]-$allhosts[$j]";
	    if (! defined $done{$route}) {
		print "$cmd\n";
		system($cmd);
		$done{$route} = 1;
	    }
	}
    }
}

################

if( $#ARGV < 3 ) { die "perl setup.pl <list of nodes> <testbed> <list of paths> <forward = 0 ie gateway to dest>"; }

$NODE_LIST = shift(@ARGV);

$TESTBED = shift(@ARGV);
die if ($TESTBED ne "map" && $TESTBED ne "emulab");

if ($TESTBED eq "map") {
    if ($WIRELESS_INTERFACE eq "ath0") {
        $IP = "1\\.0\\.0";
    }
    elsif ($WIRELESS_INTERFACE eq "wlan0") {
        $IP = "2\\.0\\.0";
    }
}
elsif ($TESTBED eq "emulab") {
    $IP = "10\\.1\\.1";
}

#get all nodes, ips and interfaces out
open(FILE,"$NODE_LIST") || die "could not open $NODE_LIST for reading" ;
my $sites = "";
while (my $line = <FILE>) {
    $sites .= $line;
}
close(FILE);
@allhosts = ($sites =~ m|HOST NAME=\"(.*?)\"|sig);
foreach my $h (@allhosts) {
    my $int = get_interface($h);
    $allinterfaces{$h} = $int;
    $allips{$h} = get_ip($h);
}

#3. set up routing
cleanup_routing();
print "-----------------------------------------------\n";

open(FILE,"$ARGV[0]") || die "could not open $ARGV[0] for reading" ;
while (my $line = <FILE>) {
    @allhosts = ();
    #@allhosts --> path from recvr to gateway
    chomp $line;
    my @alltemp = split(/ +/, $line);

    if ($ARGV[1] != 0) {
	@allhosts = @alltemp;
    }
    else {
	#flip the route
	for (my $hik = $#alltemp; $hik >= 0; $hik--) {
	    push(@allhosts, $alltemp[$hik]);
	}
    }
    
    setup_hard_route();
    print "-----------------------------------------------\n";
}
close(FILE);




