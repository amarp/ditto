#!/usr/bin/perl -W

use strict 'vars';

if( $#ARGV < 0 ) { die "perl setup.pl <nbr info>"; }

my %units = ();

open(FILE,"$ARGV[0]") || die "could not open $ARGV[0] for reading" ;
while (my $line = <FILE>) {
    chomp $line;
    my @allwords = split(/ +/, $line);
    
    my $src = $allwords[1];
    $src =~ s/map//;
    
    for (my $i = 2; $i <= $#allwords; $i++) {
	my $dest = $allwords[$i];
	$dest =~ s/map//;
	
	$i++;
	my $bw = $allwords[$i];

	print "$bw\n";
	my $key = "$src-$dest";
	my $key1 = "$dest-$src";
	
	if ($bw > 0) {
	    $i++; #to eat up the units
	    if ($bw > 500) {
		$bw = 1000/$bw;
	    }
	    else {
		$bw = -1;
	    }
	}
	
	if ($bw > 0) {
	    if (!defined $units{$key1}) {
		$units{$key} = $bw;
		$units{$key1} = $bw;
	    }
	    else {
		if ($units{$key1} < $bw) {
		    $units{$key} = $units{$key1}
		}
		else {
		    $units{$key} = $bw;
		    $units{$key1} = $bw;
		}
	    }
	}
    
	$i++; #separator
    }
}
close(FILE);

foreach my $k (keys %units) {
    my $src; 
    my $dest;
    if ($k =~ /(\d+)\-(\d+)/) {
	$src = $1;
	$dest = $2;
    }
    else {
	die;
    }
    print "GRAPHENTRY $src $dest $units{$k}\n";
}
