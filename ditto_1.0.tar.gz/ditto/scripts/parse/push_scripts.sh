#!/bin/bash -x

scp graph_*.rb aphanish@moo.cmcl.cs.cmu.edu:/disk/agami1/aphanish/share/emulab/
scp graph_*.rb aphanish@moo.cmcl.cs.cmu.edu:/disk/agami1/aphanish/share/map/
