#include "cdht_server.h"

#define noUDP_SERV

double tAcceptCon;
double tGotQuery;
double tReply;
int debug = 0;

class key_compare : public binary_function<bamboo_key, bamboo_key, bool> {
public:
    int operator()(const bamboo_key &x, const bamboo_key &y) {
	unsigned int keylen = x.size();
	if (y.size() < x.size())
	    keylen = y.size();

	const char *a, *b;
	a = x.base();
	b = y.base();
	
	for (unsigned int i = 0; i < keylen; i++) {
	    if (a[i] < b[i]) return 1;
	    if (a[i] > b[i]) return 0;
	}
	return 0;
    }
};

list<cdht_svr, &cdht_svr::link> cdhtlist;

multimap<bamboo_key, cdht_put_info, key_compare> keyvalmap;
typedef multimap<bamboo_key, cdht_put_info>::iterator keyvaliter;
typedef multimap<bamboo_key, cdht_put_info>::const_iterator keyvalciter;
typedef pair<keyvalciter, keyvalciter> keyvalrange;

const static str usage_str = "usage:  cdht_server [-h] [-d debuglevel] [-p port]\n";

static void
usage()
{
    fatal(usage_str);
}

static void
help()
{
    fprintf(stderr, "%s", usage_str.cstr());
    fprintf(stderr,
	    "       -h ............. help (this message)\n"
	    "       -p <port> ...... port to listen on\n"
	    "       -d <debuglevel>  enable debugging output\n"
	    );
    exit(-1);
}

int main(int argc, char *argv[])
{
    int port = DEFAULT_CDHT_PORT;
    
    char ch;
    extern char *optarg;
    /*extern int optind;*/
    
    while ((ch = getopt(argc, argv, "hp:d:")) != -1)
	switch (ch) {
	case 'h':
	    help();
	case 'p':
	    port = atoi(optarg);
	    break;
	case 'd':
	    debug = atoi(optarg);
	    break;
	default:
	    usage();
	}

    cdht_svr::start_listening(port);

    //cdht_svr::start_listening_dgram(port);

    amain();
}

void cdht_svr::start_listening(int port)
{
    if (debug >= 1) warn << "Listening on port "<< port << "\n";
  
    // start the server for public requests
    int fd = inetsocket(SOCK_STREAM, port);
    if (fd < 0)
	fatal("inetsocket: %m\n");

    close_on_exec(fd);
    make_async(fd);
  
    signal(SIGPIPE, SIG_IGN);

    listen(fd, 5);

    //cant be method of class since static function doesn't have this pointer
    fdcb(fd,selread,wrap(accept_connection,fd));
}

void accept_connection(int fd)
{
    int conn_fd;
    struct sockaddr_in client_addr;
    int client_addr_len = sizeof(struct sockaddr_in);

    memset((char *)&client_addr, 0x0, sizeof(client_addr));
  
    //warn << "Accepting connection\n";

    conn_fd = accept(fd, (struct sockaddr*) &client_addr, (socklen_t *)&client_addr_len);

    if(conn_fd < 0) {
    
	warn << "Problem with incoming connection errno " << errno << "\n";
	return;

    }
    
    if (debug >= 2)
	warn << "accepted connection from "
	     << inet_ntoa(client_addr.sin_addr)
	     << " port " << ntohs(client_addr.sin_port) << "\n";
    
    close_on_exec(conn_fd);
    make_async(conn_fd);

    //make a rpc object to understand the call
    vNew cdht_svr(conn_fd, client_addr, bamboo_dht_gateway_program_2);
}


/**
 * @param fd
 *              The socket file descriptor.
 * @param sin
 *              The socket address.
 * @param prog
 *              The RPC program that will be executed.
 */

#ifdef UDP_SERV

cdht_svr::cdht_svr(int fd, const sockaddr_in &sin, rpc_program prog)
    : x(axprt_dgram::alloc(fd)), c(asrv::alloc(x, prog, wrap(this, &cdht_svr::dispatch)))
{

    cdhtlist.insert_head(this);

    clientip = sin.sin_addr;
    clientport = ntohs(sin.sin_port);
}

#else
cdht_svr::cdht_svr(int fd, const sockaddr_in &sin, rpc_program prog)
    : x(axprt_stream::alloc(fd)), c(asrv::alloc(x, prog, wrap(this, &cdht_svr::dispatch)))
{

    cdhtlist.insert_head(this);

    clientip = sin.sin_addr;
    clientport = ntohs(sin.sin_port);
}
#endif

/**
 * Execute the appropriate procedure, according to the type of the request.
 * @param sbp
 *              The service callback.
 */
void cdht_svr::dispatch(svccb *sbp)
{
    if (!sbp) {
	//warn("dispatch(): client closed connection\n");
	delete this;
	return;
    }

    switch (sbp->proc()) {
    case BAMBOO_DHT_PROC_PUT:
	cdht_put_proc(sbp);
	break;
    
    case BAMBOO_DHT_PROC_GET:
	cdht_get_proc(sbp);
	break;

    default:
	//warn << "requested unavailable procedure\n";
	sbp->reject(PROC_UNAVAIL);
	break;
    }

    //warn <<"dispatcher end \n";
}


/* The server is destroyed when connection is closed. */
cdht_svr::~cdht_svr()
{
    if (debug >= 2)
	warn("Connection closed from %s:%d\n", inet_ntoa(clientip), clientport);
    
    cdhtlist.remove(this);
}

void cdht_svr::cdht_put_proc(svccb *sbp)
{
    bamboo_put_args *arg1;
    bamboo_stat res(BAMBOO_OK);

    bamboo_key key;
    bamboo_value value;

    arg1 = sbp->Xtmpl getarg<bamboo_put_args>();
  
    if (debug >= 3)
	warn << "processing put request\n";
    
    key = arg1->key;
    value = arg1->value;
    
    //str cid(key.base(), key.size());
    //ref<dot_descriptor> dd = New refcounted<dot_descriptor>();
    //dd->id = cid;
    //warn << dd->id << "\n";

    bool isdup = false;

    keyvalciter i;
    keyvalrange range = keyvalmap.equal_range(key);

    for (i = range.first; i != range.second; i++) {
	if (!memcmp(i->second.value.base(), value.base(),
		    std::min(i->second.value.size(), value.size()))) {
	    isdup = true;
	    break;
	}
    }

    if (!isdup) {
	if (debug >= 3) warn << "inserting put request\n";
	cdht_put_info item1(key, value);
	keyvalmap.insert(make_pair(key, item1));
    } else {
	if (debug >= 3) warn << "skipping duplicate put request\n";
	/* XXX - if we supported a TTL, update it here */
    }

    sbp->replyref(res);
}

void cdht_svr::cdht_get_proc(svccb *sbp)
{
    bamboo_get_args *arg1;
    bamboo_get_res res;
    bamboo_key key;

    arg1 = sbp->Xtmpl getarg<bamboo_get_args>();
    
    if (debug >= 3) {
	warn << "--------------------------------------------\n";
	warn << "processing get request\n";
	
    }
    
    key = arg1->key;

    ref<vec<bamboo_value> > values = New refcounted<vec<bamboo_value> >;

    //cdht_put_info::debug_mmap();
    cdht_put_info::lookup_key(key, values);
  
    res.values.setsize(values->size());
    for (unsigned int i = 0; i < values->size(); i++) {
	if (debug >= 3)
	    warn << "Getting values\n";
	res.values[i] = (*values)[i];
    }
  
    sbp->replyref(res);
    
    if (debug >= 3)
	warn << "--------------------------------------------\n";
}

void
cdht_put_info::debug_mmap()
{
    warn << "--------------------------------------------\n";
    warn <<"Values with all keys\n";
    
    keyvalciter i;
    
    for (i = keyvalmap.begin(); i != keyvalmap.end(); i++) {
	//fprintf(stderr, "  Key: %20.20s  Val:  %40.40s\n",
	//i->first.base(), i->second.value.base());
	warn << "Key is " << i->first.base() << " Value is " << i->second.value.base() << "\n";
    }
}

cdht_put_info::cdht_put_info(bamboo_key &keyin, bamboo_value &valin)
{
    key = keyin;
    value = valin;
}

cdht_put_info::~cdht_put_info()
{
}

void
cdht_put_info::lookup_key(const bamboo_key key, ref<vec<bamboo_value> > values)
{
    keyvalciter i;
    keyvalrange range = keyvalmap.equal_range(key);

    for (i = range.first; i != range.second; i++) {
	values->push_back(i->second.value);
    }

    return;
}

/* Not currently used */

void cdht_svr::start_listening_dgram(int port)
{
    if (debug >= 1) warn << "Listening on UDP port "<< port << "\n";
  
    int fd = inetsocket(SOCK_DGRAM, port);
    if (fd < 0)
	fatal("inetsocket: %m\n");

    close_on_exec(fd);
    make_async(fd);
  
    signal(SIGPIPE, SIG_IGN);

    struct sockaddr_in client_addr;
    memset((char *)&client_addr, 0x0, sizeof(client_addr));
  
    vNew cdht_svr(fd, client_addr, bamboo_dht_gateway_program_2);
}



