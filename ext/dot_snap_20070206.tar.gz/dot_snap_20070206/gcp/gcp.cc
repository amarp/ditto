#include "gcp.h"

typedef enum { CLIENT_PUT, CLIENT_PUT_ONLY, CLIENT_GET, CLIENT_GET_OID } client_mode_t;

static ptr<aclnt> gtc_c;
static ptr<aclnt> gcp_c;
static ptr<asrv> gcp_s;
static char **files;
static int nfiles;
static client_mode_t mode;

struct timeval gcp_start;

static void
usage()
{
    fatal("usage: gcp [-hrnfP] [-g gchost] file [file2, ... fileN] <dest>\n");
}

static void
help()
{
    fprintf(stderr,
	    "usage: gcp [-hrn] [-g gchost] file [file2, ... fileN] <dest>\n");
    fprintf(stderr,
	    "            -h ............ help (this message)\n"
	    "            -n ............ use the 'none' cipher for ssh\n"
	    "            -f ............ pass fds to the GTCD\n"
	    "            -g <gtcd host>  use specified GTCD host\n"
	    "            -p <gtcd port>  use specified GTCD port\n"
	    "            -r ............ Operate in receive mode\n"
	    "            -P ............ Put only, do not ssh\n"
	    "\n"
	    "           <dest> is [user@]host:/path/on/remote/end\n\n"
	    "  Alternate use:  gcp dot://<OID:hints> <localfile>\n\n");
    exit(-1);
}


void
rsh_reap(int kid)
{
    // XXX:
    fatal << "rsh_reap kid exited: " << kid << "\n";
}

ref<aclnt>
pseudo_rsh_run(char *dest, bool cnone)
{

    vec<str> av;
    str gcp_rsh = getenv("GCP_RSH");
    if (!gcp_rsh) {
	gcp_rsh = DEFAULT_GCP_RSH;
    }

    str gcp_rsh_path = find_program(gcp_rsh);
    if (!gcp_rsh_path) {
	fatal << "Could not locate ssh program " << gcp_rsh << "\n";
    }
	
    av.push_back(gcp_rsh_path);
    av.push_back("-x");
    av.push_back("-a");
    if (cnone) {
        av.push_back("-c");
        av.push_back("none");
    }
    av.push_back(dest);
    printf("Running rsh to %s\n", dest);
    av.push_back("gcp -r");

    ptr<axprt_unix> gcp_x (axprt_unix_aspawnv(av[0], av));
    if (!gcp_x) {
	fatal << "Could not start remote\n";
    }
    gcp_x->allow_recvfd = false;
    pid_t pid = axprt_unix_spawn_pid;
    warn << "Started pid " << pid << "\n";
    chldcb(pid, wrap(rsh_reap));


    // Assume its already running
    warn << "pseudo running\n";
    struct sockaddr_in servaddr;
    int sockfd = socket(PF_INET, SOCK_STREAM, 0);
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(17001);

    inet_pton(AF_INET, "127.0.0.1", &servaddr.sin_addr);
    
    if (connect(sockfd, (sockaddr *) &servaddr, sizeof(servaddr)) == -1) {
	fatal << "gcp not started manually\n";
    }
    tcp_nodelay(sockfd);

    ref<axprt> x(axprt_stream::alloc(sockfd, MAX_PKTSIZE));
    return aclnt::alloc(x, gcp_program_1);
}

ref<aclnt>
rsh_run(char *dest, bool cnone)
{
    vec<str> av;
    str gcp_rsh = getenv("GCP_RSH");
    if (!gcp_rsh) {
	gcp_rsh = DEFAULT_GCP_RSH;
    }

    str gcp_rsh_path = find_program(gcp_rsh);
    if (!gcp_rsh_path) {
	fatal << "Could not locate ssh program " << gcp_rsh << "\n";
    }
	
    av.push_back(gcp_rsh_path);
    av.push_back("-x");
    av.push_back("-a");
    if (cnone) {
        av.push_back("-c");
        av.push_back("none");
    }
    av.push_back(dest);
    printf("Running rsh to %s\n", dest);
    av.push_back("gcp -r");

    ptr<axprt_unix> gcp_x (axprt_unix_aspawnv(av[0], av));
    if (!gcp_x) {
	fatal << "Could not start remote\n";
    }
    gcp_x->allow_recvfd = false;
    pid_t pid = axprt_unix_spawn_pid;
    warn << "Started pid " << pid << "\n";
    chldcb(pid, wrap(rsh_reap));
    return aclnt::alloc(gcp_x, gcp_program_1);
}

void
hack_acceptconn(int fd)
{
    warn << "yup...";
    struct sockaddr_in sin;
    socklen_t sinlen = sizeof(sin);
    bzero(&sin, sizeof(sin));
    
    int cs = accept(fd, (struct sockaddr *) &sin, &sinlen);
    if (cs < 0) {
        if (errno != EAGAIN)
            warn << "accept; errno = " << errno << "\n";
        return;
    }
    tcp_nodelay(cs);
    ref<axprt> x(axprt_stream::alloc(cs, MAX_PKTSIZE));
    gcp_s = asrv::alloc(x, gcp_program_1, wrap(get_dispatch, gtc_c));
}

void normal_acceptconn() {    
    ref<axprt> gcp_x =
	axprt_pipe::alloc(STDIN_FILENO, STDOUT_FILENO, MAX_PKTSIZE);
    gcp_s = asrv::alloc(gcp_x, gcp_program_1, wrap(get_dispatch, gtc_c));
    
}

static void
local_finish(int outfd, str err)
{
    if (outfd > 0)
	close(outfd);

    if (err)
	warn << "Transfer failed: " << err << "\n";
    
    exit(0);
}


// #define PSEUDO_TEST

#ifdef PSEUDO_TEST
static int sock;
#endif

//Note: Not sure if this code is portable 
//may need more error checking
bool 
convert_to_packed(char *d, str &out)
{
    str in(d);

    warn << "OID is " << in << "\n";
    
    bigint a;
    strbuf temp;
    
    if (in.len() != 40) 
	return false;
    
    
    temp << "0x";
    temp << in;
    
    str temp1 = temp;
    
    a = temp1 ; 
    
    // to raw
    mstr ret(20);
    mpz_get_raw(ret, 20, &a); 
    
    out = ret;
    
    if (out.len() != 20) 
	return false;
    
    return true;
}

static void
ctrlconnect(char *dest, char *destpath, bool cnone, bool passfd)
{
    /* Setup control connection */
    if (mode == CLIENT_PUT) {
#ifndef PSEUDO_TEST
        gcp_c = rsh_run(dest, cnone);
#else
	gcp_c = pseudo_rsh_run(dest, cnone);
#endif
        do_put(files, nfiles, gtc_c, gcp_c, destpath, passfd);
    }
    else if (mode == CLIENT_PUT_ONLY) {
	do_put(files, nfiles, gtc_c, NULL, NULL, passfd);
    }
    else if (mode == CLIENT_GET) {
#ifndef PSEUDO_TEST
	normal_acceptconn();
#else
	sock = inetsocket(SOCK_STREAM, 17001);
	if (sock < 0)
	    fatal("hack inetsocket: %m\n");
	
	close_on_exec(sock);
	make_async(sock);
	listen(sock, 5);
	fdcb(sock, selread, wrap(hack_acceptconn, sock));
#endif
	
    }
    else if (mode == CLIENT_GET_OID) {
	/* Dest is the OID:hints */
	int outfd;
	dot_oid_md oidmd;
	str hostname;
	unsigned int portnum = -1;
	oid_hint h;
	ref< vec<oid_hint> > hints = New refcounted<vec<oid_hint> >;

	char *d, *hn = NULL, *port = NULL;

	d = strdup(files[0] + 6); /* ignore dot:// */
	assert(d != NULL);
	if ((hn = strchr(d, ':'))) {
		*hn++ = '\0';
		//h.hostname = hn;
		if ((port = strchr(hn, ':'))) {
		    *port++ = '\0';
		    hostname = hn;
		    portnum = atoi(port);
		}
	}

	//BINDU
	//oidmd.id = d;
	str idstr;
	if (!convert_to_packed(d, idstr))
	    fatal << "gcp:: Problem in conversion to 20 bytes\n";

	oidmd.id.setsize(idstr.len());
	memcpy(oidmd.id.base(), idstr.cstr(), idstr.len());
	//BINDU

	strbuf buf;
	buf << "gtc://" << hostname << ":" << port;
	h.name = buf;
	hints->push_back(h);
	
	/* Ugly - shouldn't override files like this! */
	outfd = open(files[nfiles], O_WRONLY|O_CREAT|O_TRUNC, 0666);
	if (outfd == -1) {
	    fprintf(stderr, "output file:  %s\n", files[nfiles]);
	    perror("could not open output file");
	    exit(-1);
	}
	vNew get_client(oidmd, hints, outfd, gtc_c, wrap(local_finish, outfd));
	
    }
    else
        usage();
}

static void
gtc_connected(char **argv, int argc, char *dest, char *destpath, int fd, 
              bool cnone, bool passfd)
{
    if (fd == -1)
	fatal("Could not open put_client-gtc socket: %m\n");

    // warn("Connected via FD: %d\n", fd);

    /* Setup GTC connection */
    ref<axprt_unix> gtc_x = axprt_unix::alloc(fd, MAX_PKTSIZE);
    gtc_c = aclnt::alloc(gtc_x, gtc_program_1);

    files = argv;
    nfiles = argc;

    ctrlconnect(dest, destpath, cnone, passfd);
}

int
main(int argc, char * argv[])
{
    extern char *optarg;
    extern int optind;
    char ch;
    char *gtchost = "127.0.0.1";
    //    int gtcport = 12000;
    char *dest = NULL;
    char *destpath = NULL;
    str gcp_connect_host("/tmp/gtcd.sock");
    bool cnone = false;
    bool passfd = false;
    /* XXX - probably replace that IP with localhost again when we've
     * debugged the libasync DNS dependency */

    gettimeofday(&gcp_start, NULL);    
    setprogname(argv[0]);

    mode = CLIENT_PUT;
    
    while ((ch = getopt(argc, argv, "hrnfg:p:P")) != -1)
	switch(ch) {
 	case 'p':
 	    gcp_connect_host = optarg;
 	    break;
	case 'r':
	    mode = CLIENT_GET;
	    break;
	case 'P':
	    mode = CLIENT_PUT_ONLY;
	    break;
	case 'g':
	    gtchost = optarg;
	    break;
	case 'n':
            cnone = true;
            break;
	case 'f':
            passfd = true;
            break;
	case 'h':
	    help();
	default:
	    usage();
	}

    argc -= optind;
    argv += optind;

    if (mode == CLIENT_PUT && argv[0] && !strncmp(argv[0], "dot://", 6))
	mode = CLIENT_GET_OID;

    if (mode == CLIENT_PUT) {
	if (argc < 2)
	    usage();
	dest = strdup(argv[argc-1]);
	assert(dest != NULL);
	destpath = strchr(dest, ':');
	if (!destpath) {
	    warnx << "Invalid destination: " << dest << "\n";
	    usage();
	}
	*destpath++ = '\0';
    }

    int fd = unixsocket_connect(gcp_connect_host);
    if (fd < 0)
        fatal("%s: %m\n", gcp_connect_host.cstr());

    int numfiles;
    if (mode == CLIENT_PUT_ONLY)
	numfiles = argc;
    else
	numfiles = argc - 1;

    gtc_connected(&argv[0], numfiles, dest, destpath, fd, cnone, passfd);

    amain();
    /* XXX - notreached... */
    if (dest) {
	free(dest);
    }
}
