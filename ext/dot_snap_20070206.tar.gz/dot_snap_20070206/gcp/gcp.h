#ifndef _GCP_H_
#define _GCP_H_ 1

#include "async.h"
#include "arpc.h"
#include "gcp_prot.h"
#include "gtc.h"
#include "util.h"
#include "bigint.h"

#define DEFAULT_GCP_RSH "ssh"

typedef callback<void, str, ptr<dot_oid_md> >::ref put_done_cb;

class gcp_put {
    str file;
    str destpath;
    ref<aclnt> gtc_c;
    ptr<aclnt> gcp_c;
    put_done_cb cb;

    dot_xferId xferId;
    unsigned int pendingRPCs;

    int in_fd;

    struct stat statbuf;

    void send_file(bool passfd);
    void gcp_send(str err, ptr<dot_oid_md> oid, ptr<vec<oid_hint> > hints);

    void put_done(ref<gcp_put_res> res, clnt_stat err);
    
public:
    gcp_put(str file, str dp, ref<aclnt> gtc, ptr<aclnt> gcp, bool passfd,
            put_done_cb cb);
    ~gcp_put();
};

extern void do_put(char **files, int numfiles, ref<aclnt> gtc_c, 
                   ptr<aclnt> gcp_c, char *destpath, bool passfd);
extern void get_dispatch(ref<aclnt> gtc_c, svccb *sbp);

#endif /* _GCP_H_ */
