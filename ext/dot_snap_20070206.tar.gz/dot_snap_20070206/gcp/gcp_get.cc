#include "gcp.h"
static struct timeval start;
static struct timeval end;

static void
finish(svccb *sbp, int outfd, str err)
{
    if (outfd > 0)
        close(outfd);

    gettimeofday(&end, NULL);
    fprintf(stderr, "time for GCP_PROC_PUT start-finish == %.2f\n",
	    timeval_diff(&start, &end));

    if (err) {
        gcp_put_res res (false);
        *res.errmsg = err;
        sbp->replyref(res);
    }
    else {
        gcp_put_res res (true);
        sbp->replyref(res);
    }
}

int
setup_file(file_struct fs)
{
    struct stat sb;
    strbuf outf;
    str s;
    
    if (fs.destpath && 0 == stat(fs.destpath, &sb) && (sb.st_mode & S_IFDIR)) {
	str dp = fs.destpath;
	str fn = fs.filename;
	s = outf.fmt("%s/%s", dp.cstr(), fn.cstr());
    } 
    else {
	s = fs.destpath;
    }

    int outfd = open(s, O_WRONLY|O_CREAT|O_TRUNC, 0666);
    if (outfd < 0) {
        warn("open %s: %m\n", s.cstr());
        return -1;
    }

    if (fchmod(outfd, fs.mode) < 0) {
        warn("fchmod %s: %m\n", s.cstr());
        return -1;
    }

    return outfd;
}

void
get_dispatch(ref<aclnt> gtc_c, svccb *sbp)
{
    if (!sbp) {
	warn("gc::dispatch(): client closed connection\n");
	/* XXX - need something to keep track of our state.  */
	exit(0);
    }

    switch(sbp->proc()) {
    case GCP_PROC_PUT: {
	gettimeofday(&start, NULL);
        int outfd;
        gcp_put_arg *arg = sbp->Xtmpl getarg<gcp_put_arg>();
        
        if ((outfd = setup_file(arg->file)) >= 0) {
            ref<vec<oid_hint> > hints = New refcounted<vec<oid_hint> >;
            // warn << "we got hints == " << arg->hints.size() << "\n";
            for(unsigned int i = 0;  i < arg->hints.size(); i++) {
              // warn << "Hint: host:port is " << arg->hints[i].hostname << ":" <<
              // arg->hints[i].port << "\n";
              //New refcounted<oid_hint> hint = hints[0];
              hints->push_back(arg->hints[i]);
            }
            vNew get_client(arg->oid, hints, outfd, gtc_c, wrap(finish, sbp, 
                                                                outfd));
        }
        else {
	    gcp_put_res res (false);
	    *res.errmsg = "could not open remote file";
	    sbp->replyref(res);
	}
	break;
    }
    default:
	sbp->reject(PROC_UNAVAIL);
	break;
    }
}
