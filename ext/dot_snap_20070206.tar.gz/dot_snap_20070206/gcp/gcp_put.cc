#include "gcp.h"

static int put_files;
static struct timeval tv_hash_start;
static struct timeval tv_data_start; // This is also tv_hash_end
static struct timeval tv_data_end;


gcp_put::gcp_put(str file, str dp, ref<aclnt> gtc, ptr<aclnt> gcp,
                 bool passfd, put_done_cb cb)
    : file(file), destpath(dp), gtc_c(gtc), gcp_c(gcp), cb(cb)
{
    pendingRPCs = 0;

    send_file(passfd);
}

void
gcp_put::send_file(bool passfd)
{
    warn << "Sending file " << file << "\n";
    if (!strcmp(file, "-"))
	in_fd = STDIN_FILENO;
    else
	in_fd = open(file, O_RDONLY);

    if (in_fd == -1) {
        strbuf sb;
        sb.fmt("Could not open input file: %s: %m", file.cstr());
        (*cb) (sb, NULL);
        return;
    }

    if (fstat(in_fd, &statbuf) == -1) {
	strbuf sb;
	sb.fmt("Could not stat input file: %s: %m", file.cstr());
	(*cb) (sb, NULL);
	return;
    }

    gettimeofday(&tv_hash_start, NULL);

    if (passfd) {
        vNew put_client_fd(in_fd, gtc_c, wrap(this, &gcp_put::gcp_send));
    }
    else {
        vNew put_client(in_fd, gtc_c, wrap(this, &gcp_put::gcp_send));
    }

}

void 
gcp_put::gcp_send(str err, ptr<dot_oid_md> oid, ptr<vec<oid_hint> > hints)
{
    if (err) {
        strbuf sb;
	sb << "gcp_put:  Putting to the GTC failed! " << err << "\n";
	(*cb) (err, NULL);
	return;
    }

    if (gcp_c == NULL) {
	warn << "gcp_c is null, done\n";
	(*cb)(NULL, oid);
	return;
    }

    gettimeofday(&tv_data_start, NULL);

    gcp_put_arg arg;
    arg.oid = *oid;
    arg.hints.set(hints->base(), hints->size());
    arg.file.size = statbuf.st_size;
    arg.file.uid = statbuf.st_uid;
    arg.file.gid = statbuf.st_gid;
    arg.file.mode = statbuf.st_mode;
    arg.file.modtime = statbuf.st_mtime;

    strbuf filename;
    char *lastslash = strrchr(file, '/');
    if (lastslash) {
	filename << (lastslash + 1);
    } else {
	filename << file;
    }

    arg.file.filename = filename;
    arg.file.destpath = destpath;

    ref<gcp_put_res> cli_res = New refcounted<gcp_put_res>;
    gettimeofday(&tv_data_start, NULL);
    gcp_c->call(GCP_PROC_PUT, &arg, cli_res,
		wrap(this, &gcp_put::put_done, cli_res));
}

extern struct timeval gcp_start;
void
gcp_put::put_done(ref<gcp_put_res> res, clnt_stat err)
{
    if (err) {
	strbuf sb;
        sb << "Could not send put command to receiver: " << err << "\n";
        (*cb) (sb, NULL);
        return;
    }
    if (!res->ok) {
        strbuf sb;
	sb << "put_done returned " << *res->errmsg << "\n";
        (*cb) (sb, NULL);
        return;
    }
    gettimeofday(&tv_data_end, NULL);
    
    // XXX - Why does warn not support floats??
    printf ("Yay!  Put succeeded - Hash Time: %.2f, Data Time %.2f, Total Running Time %.2f \n ",
	    timeval_diff(&tv_hash_start, &tv_data_start),
	    timeval_diff(&tv_data_start, &tv_data_end),
	    timeval_diff(&gcp_start, &tv_data_end));

    (*cb) (NULL, NULL);
}

static void
do_put_done(char *filename, bool print_oid, str err, ptr<dot_oid_md> oid)
{
    if (err)
        warn << err << "\n";

    if (print_oid) {
	strbuf o;
	o << oid->id;
	str foo(o);
	printf("PUT_OID:%s:%s\n", foo.cstr(), filename);
    }


    if (--put_files)
        return;

    warn << "Done sending all files\n";
    exit(0);
}

void
do_put(char **files, int numfiles, ref<aclnt> gtc_c, ptr<aclnt> gcp_c,
       char *destpath, bool passfd)
{
    put_files = numfiles;

    for (int i = 0; i < numfiles; i++) {
	warn << "gcpputting " << files[i] << "\n";
	/* Ugliness.  gcp_c == NULL is a sign that we're doing client
	 * put only mode, so print out the OID. */
        vNew gcp_put(files[i], destpath, gtc_c, gcp_c, passfd,
                     wrap(do_put_done, files[i], (gcp_c == NULL)));
    }
}

