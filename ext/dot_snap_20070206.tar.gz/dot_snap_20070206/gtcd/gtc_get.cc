/*
 * Copyright (c) 2005-2006 Carnegie Mellon University and Intel Corporation.
 * All rights reserved.
 * See the file "LICENSE" for licensing terms.
 */

#include "gtc.h"

get_client::get_client(dot_oid_md oid, ref<vec<oid_hint> > hints, int out_fd, 
                       ref<aclnt> gtc, cbs cb)
    : oid(oid), out_fd(out_fd), gtc_c(gtc), cb(cb)
{
    gtc_get_init_arg fetch_arg;
    fetch_arg.oid = oid;
    fetch_arg.hints.set(hints->base(), hints->size());
    fetch_arg.xmode = XFER_OUT_OF_ORDER;

    ref<gtc_get_init_res> res = New refcounted<gtc_get_init_res>;
    warn << "gc::gc asking for oid " << oid.id << "\n";
    gtc_c->call(GTC_PROC_GET_INIT, &fetch_arg, res,
                wrap(this, &get_client::get_start, res));
}

void
get_client::get_start(ref<gtc_get_init_res> res, clnt_stat err)
{
    if (err) {
        strbuf sb;
        sb << "gc::get_start(): GTC_PROC_GET_INIT RPC failure: " << err << 
          "\n";
        finish(sb);
        return;
    }
    if (!res->ok) {
        strbuf sb;
        sb << "gc::get_start(): GTC_PROC_GET_INIT returned:\n`" 
           << *res->errmsg << "'\n";
        finish(sb);
        return;
    }

    xferId = *res->id; 

    gtc_get_data_arg darg = xferId;
    ref<gtc_get_data_res> dres = New refcounted<gtc_get_data_res>;
    gtc_c->call(GTC_PROC_GET_DATA, &darg, dres,
                wrap(this, &get_client::get_data, dres));
}

void
get_client::get_data(ref<gtc_get_data_res> res, clnt_stat err)
{
    if (err) {
        strbuf sb;
        sb << "gc::get_data(): GTC_PROC_GET_DATA RPC failure: " << err << "\n";
        finish(sb);
        return;
    }
    if (!res->ok) {
        strbuf sb;
        sb << "gc::get_data(): GTC_PROC_GET_DATA returned:\n  `" 
              << *res->errmsg << "'\n";
        finish(sb);
        return;
    }

    suio newdat;
    newdat.copy(res->resok->data.base(), res->resok->data.size());
    if (-1 == lseek(out_fd, res->resok->offset, SEEK_SET)) {
        finish("gc::get_data(): Unable to lseek");
        return;
    }
    newdat.output(out_fd);

    if (res->resok->end) {
        warn << "gc::Finished GET..\n";
        finish(NULL);
        return;
    }

    gtc_get_data_arg arg = xferId;
    ref<gtc_get_data_res> dres = New refcounted<gtc_get_data_res>;
    gtc_c->call(GTC_PROC_GET_DATA, &arg, dres,
                wrap(this, &get_client::get_data, dres));
}

void
get_client::finish(str err)
{
    (*cb) (err);
    delete this;
}

get_client::~get_client()
{
    warn << "gc::Destroying get_client\n";
}
