#ifndef _SE_TRANFER_H_
#define _SE_TRANFER_H_

#include "dht.h"

#define NUM_SHINGLES 30
#define DEFAULT_DHT_PORT 5852
#define noEMULAB

class Compare_dot_desc {
public:
    int operator()(const dot_desc &x, const dot_desc &y) {
	str xx = strbuf() << x;
	str yy = strbuf() << y;
	return xx < yy;
    }
};

#include <vector>
#include <queue>
typedef std::priority_queue<dot_desc,std::vector<dot_desc>,Compare_dot_desc> ordered_descriptor_list;

void put_oid_source(dht_rpc *dht, dot_oid oid, oid_hint hint, cbs cb);
void put_fp_to_oid(dht_rpc *dht, dot_desc descriptor, dot_oid oid, cbs cb);
void get_fp_oids(dht_rpc *dht, dot_desc cid,  dht_get_cb cb);
void get_oid_sources(dht_rpc *dht, dot_oid oid, dht_get_cb cb);

#endif /* _SE_TRANFER_H_ */
