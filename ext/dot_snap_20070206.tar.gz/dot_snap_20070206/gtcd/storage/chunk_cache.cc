/*
 * Copyright (c) 2005-2006 Carnegie Mellon University and Intel Corporation.
 * All rights reserved.
 * See the file "LICENSE" for licensing terms.
 */

#include "gtcd.h"
#include "chunk_cache.h"

#define MAX_CHUNKS_MEM_FOOTPRINT    ((size_t)(100*1024*1024))  // 100 MB
#define CHUNKS_HIGH_WATER           ((size_t)(((double)MAX_CHUNKS_MEM_FOOTPRINT * 90)/100))
#define CHUNKS_LOW_WATER            ((size_t)(((double)MAX_CHUNKS_MEM_FOOTPRINT * 60)/100))

#define CHUNK_PURGER_SEC    1200
#define CHUNK_PURGER_NSEC   000

chunk::chunk(const dot_desc hash, const char *buf, unsigned int length) 
    : hash(hash), data(New refcounted<suio>), refcount(1), status(CHUNK_IN_MEM)
{
    desc.id = hash;
    desc.length = length;
    data->copy(buf, length);
}

chunk::chunk(const dot_desc hash, ref<suio> indata) 
    : hash(hash), refcount(1), status(CHUNK_IN_MEM)
{
    desc.id = hash;
    desc.length = indata->resid();
    data = indata;
}

chunk::~chunk() 
{
}

chunkCache::chunkCache(const str cache_path)
    : cache_path(cache_path), mem_footprint(0)
{
    purger = delaycb(CHUNK_PURGER_SEC, CHUNK_PURGER_NSEC, wrap(this, &chunkCache::purge_chunks));
}

void
chunkCache::purge_cb(chunk *ck)
{
    if (ck->refcount == 0) {
        if (ck->status == CHUNK_IN_MEM || ck->status == CHUNK_IN_MEM_ON_DISK) {
            //warn << "about to remove from mem "<< ck->desc.id << "\n";
            mem_lru.remove(ck);
            mem_footprint -= ck->data->resid();
            ck->data = NULL;
        } 
        if (ck->status == CHUNK_IN_MEM_ON_DISK || ck->status == CHUNK_ON_DISK) {
            unlink_chunk(ck->desc.id);
        }
        chunk_cache.remove(ck);
        delete ck;
    }
}

void
chunkCache::purge_chunks()
{
    chunk_cache.traverse(wrap(this, &chunkCache::purge_cb));
    purger = delaycb(CHUNK_PURGER_SEC, CHUNK_PURGER_NSEC, wrap(this, &chunkCache::purge_chunks));
}

void
chunkCache::cache_pressure_cb(chunk *ck)
{

    if (mem_footprint <= CHUNKS_LOW_WATER) {
        return;
    }

    if (ck->refcount == 0) {
        if (ck->status == CHUNK_IN_MEM) {
            chunk_cache.remove(ck);
            mem_lru.remove(ck);
            
            mem_footprint -= ck->data->resid();
            ck->data = NULL;
            delete ck;
	    return;
        } 
        else if (ck->status == CHUNK_IN_MEM_ON_DISK) {
            // This needs to cleaned up by the purger. So we leave enough
            // state around
            mem_lru.remove(ck);

            mem_footprint -= ck->data->resid();
            ck->data = NULL;
            ck->status = CHUNK_ON_DISK;
	    return;
        }
        else {
            fatal << "remove_zero_refcount: Unknown state for chunk\n";
        }
    }
    
    if (ck->status == CHUNK_IN_MEM) {
        // write it out to disk
        mem_lru.remove(ck);
        mem_footprint -= ck->data->resid();
        write_chunk(ck->desc.id, ck->data);
        ck->status = CHUNK_ON_DISK;
        ck->data = NULL;
    }
    else if (ck->status == CHUNK_IN_MEM_ON_DISK) {
        mem_lru.remove(ck);
        ck->status = CHUNK_ON_DISK;
        mem_footprint -= ck->data->resid();
        ck->data = NULL;
    }
    else {
        fatal << "remove_zero_refcount: Unknown state for chunk\n";
    }
}

void
chunkCache::sync_chunks()
{
    mem_lru.traverse(wrap(this, &chunkCache::cache_pressure_cb));
    syncer = NULL;
}

void
chunkCache::check_footprint() 
{
    if (mem_footprint >= CHUNKS_HIGH_WATER && !syncer) {
        syncer = delaycb(0, 0, wrap(this, &chunkCache::sync_chunks));
    }
        
}

chunk *
chunkCache::getChunk(const dot_desc name) 
{
    return chunk_cache[name];
}


chunk *
chunkCache::new_chunk(const dot_desc name, const char *buf, unsigned int length)
{
    chunk *ck = New chunk(name, buf, length);
    chunk_cache.insert(ck);
    mem_lru.insert_tail(ck);

    mem_footprint += length;
    check_footprint();

    return ck;
}

chunk *
chunkCache::new_chunk(const dot_desc name, ref<suio> data)
{
    chunk *ck = New chunk(name, data);
    chunk_cache.insert(ck);
    mem_lru.insert_tail(ck);

    mem_footprint += data->resid();
    check_footprint();
    
    // for debugging only
    // write_chunk(ck->desc.id, ck->data);

    return ck;
}


bool
chunkCache::write_chunk(dot_desc chunkname, ref<suio> data)
{
    char path[PATH_MAX];
    int fd;
    int written;

    // warn << "about to write out " << chunkname << "\n";
    suio uiop;
    uiop.copyu(data);
    // warn<< data->resid() << "," << uiop.resid()  << " "  ;
    path[0] = '\0';
    strcat(path, cache_path);
    strcat(path, "/");
    str ss = strbuf() << chunkname;
    strcat(path, ss);

    struct stat sb;
    if (-1 == stat(path, &sb)) {
        // Does not exist.  Write the chunk to disk.

        fd = open(path, O_CREAT | O_WRONLY | O_TRUNC, S_IRUSR | S_IWUSR);
        if (fd == -1) {
            warn << "Unable to open" << path << " for writing \n";
            return false;
        }
        written = uiop.output(fd);
        if (written != 1) {
            warn << "Unable to write entire file to " << path << ".\n";
            close(fd);
            return false;
        }
        close(fd);
        return true;
    } 
    else {
        return true;
    }
}

bool 
chunkCache::unlink_chunk(dot_desc chunkname)
{
    char path[PATH_MAX];
    path[0] = '\0';
    strcat(path, cache_path);
    strcat(path, "/");
    str ss = strbuf() << chunkname;
    strcat(path, ss);
    // warn << "About to unlink " << chunkname << "\n";
    struct stat sb;
    if (-1 == stat(path, &sb)) {
        return true;
    } 
    else {
        if (-1 == unlink(path)) {
            warn << "Unable to unlink " << path << "\n";
            return false;
        }
        return true;
    }

}

ptr<suio>
chunkCache::get_chunk_data(const dot_desc cname)
{
    char name[PATH_MAX];
    int fd;

    chunk *ck = chunk_cache[cname];

    if (!ck) {
	return NULL;
    }

    if (ck->status == CHUNK_IN_MEM || ck->status ==  CHUNK_IN_MEM_ON_DISK) {
        mem_lru.remove(ck);
        mem_lru.insert_tail(ck);
        return ck->data;
    }

    if (ck->status != CHUNK_ON_DISK) {
        warn << "Unknown chunk status\n";
        return NULL;
    }

    ref<suio> data = New refcounted<suio>;
    name[0] = '\0';
    strcat (name, cache_path);
    strcat (name, "/");
    str ss = strbuf() << cname;
    strcat (name, ss);
    //  warn("Checking for %s\n", cname);

    fd = open(name, O_RDONLY);
    if (fd < 0) {
	warn("Unable to find %s\n", name);
	return NULL;
    }
    int ret;
    do {
        ret = data->input(fd);
    } while (ret > 0);

    if (ret == -1) {
        if (errno == EAGAIN) {
            fatal << "Implement support for EAGAIN\n";
        }
        else {
            warn << "Error when reading file\n";
        }
    }

    close(fd);
    ck->data = data;
    ck->status = CHUNK_IN_MEM_ON_DISK;
    mem_lru.insert_tail(ck);

    return ck->data;
}
