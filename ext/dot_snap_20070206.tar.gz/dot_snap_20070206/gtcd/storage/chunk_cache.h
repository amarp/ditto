/*
 * Copyright (c) 2005-2006 Carnegie Mellon University and Intel Corporation.
 * All rights reserved.
 * See the file "LICENSE" for licensing terms.
 */

#ifndef _CHUNK_CACHE_H_
#define _CHUNK_CACHE_H_ 1

#include "list.h"
#include "async.h"
#include "ihash.h"


enum chunk_status {
    CHUNK_IN_MEM,
    CHUNK_ON_DISK,
    CHUNK_IN_MEM_ON_DISK
};

// Chunks are separate from descriptors because multiple dot_descs might
// point to the same chunk.
struct chunk {
    dot_descriptor desc;
    const dot_desc hash;
    ptr<suio> data;
    int refcount;
    chunk_status status;

    ihash_entry<chunk> hlink;
    tailq_entry<chunk> tlink;

    chunk (const dot_desc hash, const char *buf, unsigned int length);
    chunk (const dot_desc hash, ref<suio> indata);
    ~chunk ();
};

class chunkCache {

private:
    ihash<const dot_desc, chunk, &chunk::hash, &chunk::hlink, dd_hash> chunk_cache;
    // The talk of this list is the most recently used element
    tailq<chunk, &chunk::tlink> mem_lru;
    const str cache_path;
    size_t mem_footprint;
    // Write unwritten blocks to disk in the face of cache pressure
    timecb_t *syncer;
    // Purge chunks whose refcount has hit zero
    timecb_t *purger;

    void purge_chunks();
    void purge_cb(chunk *ck);
    void sync_chunks();
    void cache_pressure_cb(chunk *ck);

    bool write_chunk(dot_desc chunkname, ref<suio> data);
    bool unlink_chunk(dot_desc chunkname);
    void check_footprint();
public:
    chunk *getChunk(const dot_desc name);
    chunk *new_chunk(const dot_desc name, const char *buf, unsigned int length);
    chunk *new_chunk(const dot_desc name, ref<suio> data);
    ptr<suio> get_chunk_data(const dot_desc name);

    chunkCache(const str cache_path);
};

#endif /* _CHUNK_CACHE_H_ */
