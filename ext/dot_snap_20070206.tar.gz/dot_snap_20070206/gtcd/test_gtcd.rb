#!/usr/bin/env ruby

require 'tempfile'
require 'test/unit'

ENV["SHELL"] = "/bin/sh"

def spawn(kidargs)
  if pid = fork then
    return pid
  else
    $stderr.close
    exec(kidargs)
  end
end

class TC_GTC < Test::Unit::TestCase

  def test_gtc_runs
    gtcd = spawn("./gtcd")
    sleep(1)
    Process.kill(9, gtcd)
    sleep(1)
  end
  
  def test_gcp
    gtcpid = spawn("./gtcd")
    sleep(1)
  
    outfile = Tempfile.new("gcp_test")
    outpath = outfile.path
    
    oid = `./gcp -g localhost put gcp 2>/dev/null`
    oid.chomp!
    
    system("./gcp -g localhost get #{oid} > #{outpath} 2>/dev/null")
    
    diff = `diff -q gcp #{outpath}`
    if (diff =~ /differ/)
      assert(false, "The output files differed")
    end
  ensure
    if (gtcpid)
      Process.kill(9, gtcpid)
    end
    if (outfile)
      outfile.unlink
    end
  end
end
