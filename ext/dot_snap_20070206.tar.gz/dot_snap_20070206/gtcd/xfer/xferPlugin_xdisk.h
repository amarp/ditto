/*
 * Copyright (c) 2005-2006 Carnegie Mellon University and Intel Corporation.
 * All rights reserved.
 * See the file "LICENSE" for licensing terms.
 */

#ifndef _XFER_XDISK_H_
#define _XFER_XDISK_H_

#include "xferPlugin.h"
#include "chunker/chunkerPlugin_all.h"
#include "gtcd.h"
#include "xferPlugin_gtc_prot.h"

#include <sys/types.h>
#include <dirent.h>
#include "aiod.h"
//#include <db_cxx.h>
//#define DB_HOME_PATH    "/tmp/db"

#define FRESH_THRESH 10*60 //10 minutes

typedef callback<void, bool, str >::ref cb_bool;

class ioh {
    
public:
    virtual ~ioh() {};
    virtual void opendir(str path, cbs cb, CLOSURE) = 0;
    virtual void readdir(struct dirent *,cb_bool cb, CLOSURE) = 0;
    virtual void closedir(cbs cb, CLOSURE) = 0;
    virtual void stat(str name, struct stat *res, cbs cb, CLOSURE) = 0;
};

class sioh : public ioh {
    
private:
    DIR *fp;
    
public:
    sioh() { }
    ~sioh() { }
    virtual void opendir(str path, cbs cb, CLOSURE);
    virtual void readdir(struct dirent *, cb_bool cb, CLOSURE);
    virtual void closedir(cbs cb, CLOSURE);
    virtual void stat(str name, struct stat *res, cbs cb, CLOSURE);
};

class aioh : public ioh {
    
private:
    aiod *a;
    ptr<aiofh> fh;
    ptr<aiobuf> buf;

public:
    aioh(aiod *ptr) : a(ptr) { }
    ~aioh() { }
    virtual void opendir(str path, cbs cb, CLOSURE);
    virtual void readdir(struct dirent *, cb_bool cb, CLOSURE);
    virtual void closedir(cbs cb, CLOSURE);
    virtual void stat(str name, struct stat *res, cbs cb, CLOSURE);
};

struct list_cache_entry {
    const str path;
    ihash_entry<list_cache_entry> hlink;

    ptr<vec<str> > list;
    double update_time;
    
    list_cache_entry(const str);
    ~list_cache_entry();
};

struct stat_cache_entry {
    const str path;
    ihash_entry<stat_cache_entry> hlink;

    ptr<vec<struct item_info> > list;
    double update_time;
    
    stat_cache_entry(const str);
    ~stat_cache_entry();
};


struct item_info {
    str name;
    struct stat s;
};

class xferPlugin_xdisk : public xferPlugin, public storagePlugin {
  
private:
    gtcd_main *m;
    xferPlugin *xp;
    aiod *aiod_ptr;
    
    //DbEnv *dbenv;
    //Db *filesDb;

    chunkerPlugin *cp;
    storagePlugin *sp;
    
public:
    bool configure(str s) { return true; }
    
    /* This should only be called after initialization */
    void get_default_hint(oid_hint *hint);

    /* Calls from the GTC */
    void get_descriptors(ref<dot_oid_md> oid, ref<vec<oid_hint> > hints,
			 descriptors_cb cb, CLOSURE);
    void get_bitmap(ref<dot_oid_md> oid, ref<vec<oid_hint> > hints,
		    bitmap_cb cb, CLOSURE);
    void notify_descriptors(ref<dot_oid_md> oid, ptr<vec<dot_descriptor> > descs);
    void get_chunk(ref<dot_descriptor> d, ref<vec<oid_hint> > hints,
                   chunk_cb cb, CLOSURE);
    void get_chunks(ref< vec<dot_descriptor> > dv, ref<hv_vec > hints,
		    chunk_cb cb, CLOSURE);

    void cancel_chunk(ref<dot_descriptor> d);
    void cancel_chunks(ref< vec<dot_descriptor> > dv);

    void update_hints(ref< vec<dot_descriptor> > dv, ref<hv_vec > hints);

    /* Optimizer interface */
    void get_cost_op(xfer_op opid, xfer_unit u, str arg);
    void perform_op(xfer_op opid, str arg, unsigned int depth, cbs cb, CLOSURE);
    
    xferPlugin_xdisk(gtcd_main *m, xferPlugin *next_xp);
    ~xferPlugin_xdisk() { }

    /* Storage interface */
    
    bool init(dot_sId id) { return true; }
        
    void put_chunk(dot_sId id, ref<dot_descriptor> d,
                   const char *buf, int len, cbs cb, CLOSURE) { }
    void commit_object(dot_sId id, commit_cb cb, CLOSURE) { }
    bool release_object(ref<dot_oid> oid) { return true; }
        

    void put_ichunk(ref<dot_descriptor> d, ref<suio> uiop,
                    bool retain, cbs cb, CLOSURE) { }
    bool release_ichunk(ref<dot_descriptor> d) { return true; }


    void get_descriptors_init(ref<dot_oid_md> oid, oid_cb cb, CLOSURE) { }
    void get_descriptors(ref<dot_oid_md> oid, descriptors_cb cb, CLOSURE) { }
    //void notify_descriptors(ref<dot_oid_md> oid,
    //                      ptr<vec<dot_descriptor> > descs);
    void get_bitmap(ref<dot_oid_md> oid, bitmap_cb cb, CLOSURE) { }
    void get_chunk_init(ref<dot_descriptor> d, descriptor_cb cb, CLOSURE) { }
    void get_chunk(ref<dot_descriptor> d, chunk_cb cb, CLOSURE) { }
    int get_chunk_refcount(dot_descriptor *d) { return(1); }
        
    void inc_chunk_refcount(dot_descriptor *d) { }
        
    void get_chunks(ref< vec<dot_descriptor> > dv, chunk_cb cb, CLOSURE) { }

 private:
    void get_descriptors_cb(descriptors_cb cb1, str s, ptr<vec<dot_descriptor> > descs, bool end);
    void get_bitmap_cb(bitmap_cb cb1, str s, ptr<bitvec> bmp);
    void perform_list(str path, ptr<vec<str> > list, cbs cb, CLOSURE);
    void get_list(str path, ptr<vec<str> > res, bool async, cbs cb, CLOSURE);
    void perform_stat(str path, ptr<vec<struct item_info> > stats, cbs cb, CLOSURE);
    void get_stats(str path, ptr<vec<struct item_info> > res, bool async, cbs cb, CLOSURE);
    void perform_rlist(str path, unsigned int depth, cbs cb, CLOSURE);
    void perform_hash(str path, cbs cb, CLOSURE);
    void put_fd_main(ref<putfd_state> st, cbs cb);
    void put_fd_read(ref<putfd_state> st, cbs cb);
    void put_fd_read_cb(ref<putfd_state> st, cbs cb, str s);
    void put_fd_commit_cb(ref<putfd_state> st, cbs cb, str s, ptr<dot_oid_md> oid);
};


#endif /* _XFER_NET_H_ */
