#include "async.h"

/*
 * connectionCache is like a tcpconnect that only establishes
 * a single connection to a host.  Multiple concurrent connect
 * requests get buffered and called back together when the connection
 * is finally established.
 */

struct pending_conn_entry;
struct conn_entry;

class connectionCache {
public:
    connectionCache();
    ~connectionCache();

    connect(str ip, int port, cbi cb);

private:
    ihash<const str, pending_conn_entry, &pending_conn_entry::key,
	  &pending_conn_entry::hlink> pendingConnCache;
    
    ihash<const str, conn_entry, &conn_entry::key, &conn_entry::hlink> 
	connCache;
};

struct pending_conn_entry {
    const str key;
    ihash_entry<pending_conn_entry> hlink;
    vec<conn_cb> pending_cbs;
    pending_conn_entry (const str key);
};

struct conn_entry {
    int fd;
    const str key;
    ref<aclnt> c;
    int refcount;
    struct timeval tv;
    ihash_entry<conn_entry> hlink;

    vec<wait_conn_cb> wait_cb;
    conn_entry (const str &key, ref<aclnt> c);
    ~conn_entry ();
};
